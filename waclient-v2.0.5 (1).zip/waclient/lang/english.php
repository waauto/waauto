<?php

$_ADDONLANG['lang'] = "english";



$_ADDONLANG['newversion'] = "There is an update for addon. Please visit <a href=\"https://waclient.com/\" target='_blank' style='color:blue'>Github page</a> for download new version.<br><br>Please visit this page after file transfer finished.<br><br>";

$_ADDONLANG['uptodate'] = "Your addon is up to date.";

$_ADDONLANG['save'] = "Save";

$_ADDONLANG['gsmnumberfield'] = "Mobile Number Custom Field";

$_ADDONLANG['wantsmsfield'] = "Subscribe Message Field (Custom client field)";

$_ADDONLANG['defaultmobile'] = "Default Profile Mobile Number";

$_ADDONLANG['user'] = "Username";

$_ADDONLANG['pass'] = "Password";

$_ADDONLANG['apiid'] = "API ID";

$_ADDONLANG['email'] = "Email";

$_ADDONLANG['accesstoken']="Access Token";

$_ADDONLANG['instanceid']="Instance ID";

$_ADDONLANG['countrycode'] = "Country Code Prefix";

$_ADDONLANG['senderid'] = "SenderID";

$_ADDONLANG['typeclient'] = "Type client name";

$_ADDONLANG['username'] = "SMS Username";

$_ADDONLANG['phusername'] = "PigeonHost Email";

$_ADDONLANG['password'] = "SMS Password";

$_ADDONLANG['phpassword'] = "PigeonHost Password";

$_ADDONLANG['dateformat'] = "Date Format";

$_ADDONLANG['sender'] = "Sender";

$_ADDONLANG['settings'] = "Settings";

$_ADDONLANG['signature'] = "Signature";

$_ADDONLANG['clientsmstemplates'] = "Client Templates";

$_ADDONLANG['adminsmstemplates'] = "Admin Templates";

$_ADDONLANG['sendsms'] = "Send whatsapp";

$_ADDONLANG['messages'] = "Sent Messages";

$_ADDONLANG['update'] = "Credit Balance";

$_ADDONLANG['smssent'] = "Message Sent";

$_ADDONLANG['errorwhatsappsent'] = "Message not sent";

$_ADDONLANG['client'] = "Client";

$_ADDONLANG['selectclient'] = "Select client";

$_ADDONLANG['message'] = "Message";

$_ADDONLANG['debug'] = "Enable debug log";

$_ADDONLANG['send'] = "Send";

$_ADDONLANG['debugsonuc'] = "Result";

$_ADDONLANG['gsmnumber'] = "Mobile Number";

$_ADDONLANG['datetime'] = "Date Time";

$_ADDONLANG['status'] = "Status";

$_ADDONLANG['delete'] = "Delete";

$_ADDONLANG['parameter'] = "Parameter(s):";

$_ADDONLANG['active'] = "Activate";

$_ADDONLANG['ekstra'] = "Number of days {x}";

$_ADDONLANG['admingsm'] = "Admin Mobile Numbers";

$_ADDONLANG['admingsmornek'] = "For sending Message to multiple user use comma seperated number with country code e.g. 88017XXX,88018XXXXX";

$_ADDONLANG['lisans'] = "<br><center><a href=\"https://waclient.com/\" target='_blank'>Module Developed by WA Client</center></a>";

$_ADDONLANG['credit'] = "Remaining Credit";

$_ADDONLANG['support'] = "Support";

$_ADDONLANG['cmodulesversion'] = "Your Current Modules Version : 2.0.4<br> ";

$_ADDONLANG['supporttitle'] = "We would be glad to help you, Please reach us these ways.<br>";

$_ADDONLANG['emailus'] = "Email Us : support@waclient.com<br><br>";

$_ADDONLANG['phoneus'] = "Phone Us : +201067470822<br>";

$_ADDONLANG['website'] = "Website : <a href=\"https://waclient.com\" target='_blank'>WACLIENT.COM</a>";



$_ADDONLANG['attachment'] = "PDF File attachment";

$_ADDONLANG['addgsmnumberfield'] = "Add Custom Field";



$_ADDONLANG['saved-successfully'] = "Changes Saved Successfully!";

$_ADDONLANG['attachmentfile'] = "Attachment File";

$_ADDONLANG['file-url'] = "Insert file link";

$_ADDONLANG['attachment-extension'] = "Images,pdf,zip,docx … and all other file types";

$_ADDONLANG['media-types'] = "Supported media types:";



$_ADDONLANG['resend'] = "Resend";



$_ADDONLANG['error'] = "Error";

$_ADDONLANG['pending'] = "Pending";

$_ADDONLANG['sent'] = "Send";

$_ADDONLANG['success'] = "Success";